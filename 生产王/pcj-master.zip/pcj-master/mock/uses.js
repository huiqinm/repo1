/*
 * @customMade: 赵宇
 * @Date: 2022-02-17 17:27:33
 * @LastEditTime: 2022-02-17 17:29:57
 * @LastEditors: YourName
 * @FilePath: \vite-vue3\mock\uses.js
 */
export default [
  {
    url: '/api/user',
    method: 'get',
    response: ({ query }) => {
      console.log('id>>>>>>>>', query.id);
      return {
        code: 0,
        message: 'ok',
        data: {
          roleName: 'admin',
          roleValue: 'admin'
        }
      };
    }
  }
];
