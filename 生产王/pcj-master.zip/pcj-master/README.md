<!--
 * @customMade: 赵宇
 * @Date: 2022-02-17 15:31:09
 * @LastEditTime: 2023-03-13 15:48:35
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\README.md
-->

# vue3 + vite

## 专门给潘成杰写的

1. 然后 vue3-super-flow 不允许滚动条运行。所以我删除了源码的绑定事件 t.preventDefault()
2. 如果删除了还不生效，是因为 vite 导致的。请在项目文件 package.json 里面的 dev 改成 "dev": "vite --force" 重启
3. 查看 [vue-draggabled中文文档](https://www.itxst.com/vue-draggable-next/tutorial.html)
4. 查看 [vue-draggabled案例](https://sortablejs.github.io/vue.draggable.next/#/transition-example-2)
