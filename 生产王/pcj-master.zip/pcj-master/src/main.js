/*
 * @customMade: 赵宇
 * @Date: 2022-02-17 15:31:09
 * @LastEditTime: 2023-02-09 14:17:58
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\src\main.js
 */
import { createApp } from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import '@/styles/index.scss';
import directives from '@/config/directives.js';
import print from 'vue3-print-nb';
router.beforeEach((to, from, next) => {
  document.title = `${to.meta.title ? to.meta.title + ' | ' : ''}  系统`;
  next();
});
let app = createApp(App);
app.use(router).use(store).use(print);
directives(app);
app.mount('#app');
