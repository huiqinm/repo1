/*
 * @customMade: 赵宇
 * @Date: 2022-02-08 13:30:11
 * @LastEditTime: 2023-04-25 11:25:51
 * @LastEditors: pancc 527847805@qq.com
 * @FilePath: \pcj\src\store\index.js
 */
import { createStore } from 'vuex';
import { post, get } from '@/api/index';
export default createStore({
  state: {
    roles: [], // 角色
    commons: {}, // 菜单
    categorys: [], // 产品分类
    user: {}, // 用户
  },
  mutations: {},
  actions: {
    // 获取角色列表
    async getRoles({ state }) {
      let { result } = await get('Role/GetList');
      state.roles = result.map(r => {
        return {
          ...r,
          label: r.roleName,
          value: r.id
        };
      });
    },
    // 获取初始化参数
    async getInit({ state }) {
      let { result } = await get('Account/GetInit');
      state.commons = result;
    },
    // 获取角色列表
    async getCategory({ state }) {
      let { result } = await post('Category/GetList', {
        pageIndex: 1,
        pageSize: 999
      });
      state.categorys = result.map(r => {
        return {
          ...r,
          ...{
            label: r.categoryName,
            value: r.id
          }
        };
      });
    },
    // 获取角色列表
    async getUser({ state }) {
      let { result } = await get('User/GetModel', {});
      state.user = result
    },
  },
  modules: {}
});
