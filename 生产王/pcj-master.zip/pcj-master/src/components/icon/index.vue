<template>
  <i class="iconfont" :class="`icon-${props.name}`"></i>
</template>

<script setup>
let props = defineProps({
  name: {
    type: String,
    default: ''
  }
});
</script>

<style lang="scss" scoped></style>
