<!--
 * @Author: pancc 527847805@qq.com
 * @Date: 2023-04-26 09:53:02
 * @LastEditors: pancc 527847805@qq.com
 * @LastEditTime: 2023-05-10 15:28:46
 * @FilePath: \pcj\src\components\o-drawer\components\auditEdit.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
    <el-dialog draggable v-model="dialog.show" width="340px" top="50px" :before-close="handleClose" class="custom-dialog">
        <el-input v-model="forms.content" :autosize="{ minRows: 2, maxRows: 4 }" type="textarea" placeholder="内容" />
        <template #footer>
            <span class="dialog-footer">
                <z-button type="" @click="handleClose" icon="close">取消</z-button>
                <z-button icon="check" @click="onSave" :loading="dialog.loading"> 确认 </z-button>
            </span>
        </template>
    </el-dialog>
</template>

<script setup>
import { reactive } from "vue";

let emit = defineEmits(['update:modelValue', 'onMoreAuditBack']);
let props = defineProps({
    modelValue: {
        type: Boolean,
        default: false
    },
    addData: {
        type: Object,
        default: () => {
            return {}
        }
    }
});


let dialog = reactive({
    show: false,
    loading: false,
});

let formsInit = () => {
    return reactive({
        id: 0,
        content: '',
        submitType: 0,  // 1 为提交审批，2为驳回审批
    });
};

let forms = formsInit();

watch(
    () => props.modelValue,
    async val => {
        dialog.show = val;
        if (!val) return;
        const formData = formsInit();
        Object.keys(formData).map(r => {
            forms[r] = props.addData[r] != undefined ? props.addData[r] : formData[r];
        });
    },
    {
        immediate: true
    }
);

const onSave = () => {
    emit('onMoreAuditBack', { id: forms.id, submitType: forms.submitType, content: forms.content });
}

// 关闭
const handleClose = () => {
    forms.content = '';
    emit('update:modelValue', false);
}
</script>
<style lang="scss" scoped></style>
