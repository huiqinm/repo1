<!--
 * @Author: pancc 527847805@qq.com
 * @Date: 2023-04-27 13:56:56
 * @LastEditors: pancc 527847805@qq.com
 * @LastEditTime: 2023-04-27 17:33:47
 * @FilePath: \pcj\src\components\o-drawer\components\workReportEdit.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
    <el-dialog draggable v-model="dialog.show" width="640px" top="50px" :before-close="handleClose" class="custom-dialog">
        <el-form class="content" :inline="true" :model="forms" label-width="100px">
            <el-row :gutter="20">
                <el-col :span="24">
                    <el-form-item class="w-100" label="内容">
                        <el-input class="w-90" v-model="forms.content" :autosize="{ minRows: 2, maxRows: 4 }"
                            type="textarea" placeholder="内容" />
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item class="w-100" label="提醒人员">
                        <el-select class="w-90" v-model="forms.officeIds" multiple placeholder="请选择">
                            <el-option v-for="item in forms.user" :key="item.id" :label="item.name" :value="item.id" />
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item class="w-100" label="附件">
                        {{ forms.content }}
                    </el-form-item>
                </el-col>

            </el-row>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <z-button type="" @click="handleClose" icon="close">取消</z-button>
                <z-button icon="check" @click="onCheck" :loading="dialog.loading"> 确认 </z-button>
            </span>
        </template>
    </el-dialog>
</template>

<script setup>
import { post } from '@/api/index';
import { reactive } from "vue";
let $message = inject('$message');

let emit = defineEmits(['update:modelValue', 'onLoad']);
let props = defineProps({
    modelValue: {
        type: Boolean,
        default: false
    },
    addData: {
        type: Object,
        default: () => {
            return {}
        }
    }
});

let dialog = reactive({
    show: false,
    loading: false,
});

let formsInit = () => {
    return reactive({
        sourceId: 0,
        sourceType: 0,
        sourceProductId: 0,
        sourceTaskId: 0,
        sourceTaskName: '',
        content: '',
        officeIds: [],
        orderAttachDatas: [],  // 附件
        user: []
    });
};

let forms = formsInit();

watch(
    () => props.modelValue,
    async val => {
        dialog.show = val;
        if (!val) return;
        const formData = formsInit();
        Object.keys(formData).map(r => {
            forms[r] = props.addData[r] != undefined ? props.addData[r] : formData[r];
        });
    },
    {
        immediate: true
    }
);

const onCheck = async () => {
    await post('OrderWorkReport/CreateOrUpdate', forms)
    $message.success("提交通过");
    emit('onLoad');
}

// 关闭
const handleClose = () => {
    forms.content = '';
    emit('update:modelValue', false);
}
</script>