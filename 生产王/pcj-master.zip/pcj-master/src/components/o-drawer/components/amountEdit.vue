<!--
 * @Author: pancc 527847805@qq.com
 * @Date: 2023-04-27 13:56:56
 * @LastEditors: pancc 527847805@qq.com
 * @LastEditTime: 2023-05-10 16:56:49
 * @FilePath: \pcj\src\components\o-drawer\components\workReportEdit.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
    <el-dialog draggable v-model="dialog.show" width="640px" top="50px" :before-close="handleClose" class="custom-dialog">
        <el-form class="content" :inline="true" :model="forms" label-width="100px">
            <el-row :gutter="20">
                <el-col :span="24">
                    <el-form-item class="w-100" label="任务金额">
                        <z-input class="w-90" v-model="forms.amount"></z-input>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item class="w-90" label="任务类型">
                        <el-switch v-model="forms.switchModel" active-text="正常" inactive-text="异常" />
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <z-button type="" @click="handleClose" icon="close">取消</z-button>
                <z-button icon="check" @click="onSave" :loading="dialog.loading"> 确认 </z-button>
            </span>
        </template>
    </el-dialog>
</template>

<script setup>
import { post } from '@/api/index';
import { reactive } from "vue";
let $message = inject('$message');

let emit = defineEmits(['update:modelValue', 'onLoad']);
let props = defineProps({
    modelValue: {
        type: Boolean,
        default: false
    },
    editData: {
        type: Object,
        default: () => {
            return {}
        }
    }
});

let dialog = reactive({
    show: false,
    loading: false,
});

let formsInit = () => {
    return reactive({
        id: 0,
        amount: 0,
        switchModel: true,
        submitType: 0, // 1.计划金额，2添加数量
    });
};

let forms = formsInit();

watch(
    () => props.modelValue,
    async val => {
        dialog.show = val;
        if (!val) return;
        const formData = formsInit();
        Object.keys(formData).map(r => {
            forms[r] = props.editData[r] != undefined ? props.editData[r] : formData[r];
        });
    },
    {
        immediate: true
    }
);

const onSave = async () => {
    emit('onAmountSubmitBack', { id: forms.id, submitType: forms.submitType, recordType: forms.switchModel ? 1 : 2, amount: forms.amount });
}

// 关闭
const handleClose = () => {
    formsInit();
    emit('update:modelValue', false);
}
</script>