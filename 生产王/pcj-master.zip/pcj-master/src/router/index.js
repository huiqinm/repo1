/*
 * @customMade: 赵宇
 * @Date: 2022-01-10 10:34:55
 * @LastEditTime: 2023-04-19 14:29:17
 * @LastEditors: pancc 527847805@qq.com
 * @FilePath: \pcj\src\router\index.js
 */
import { createRouter, createWebHashHistory } from 'vue-router';

const routes = [
  {
    path: '/',
    component: () => import(/* webpackChunkName: "index" */ '@/page/home/index.vue'),
    redirect: '/index',
    children: [
      {
        path: '/index',
        name: 'index',
        component: () => import(/* webpackChunkName: "index" */ '@/page/index/index.vue'),
        meta: {
          title: '首页'
        }
      },
      // #region 权限管理
      {
        path: '/user',
        name: 'user',
        component: () => import(/* webpackChunkName: "user" */ '@/page/auth/user.vue'),
        meta: {
          title: '用户管理',
          cache: true
        }
      },
      {
        path: '/role',
        name: 'role',
        component: () => import(/* webpackChunkName: "role" */ '@/page/auth/role.vue'),
        meta: {
          title: '角色管理',
          cache: true
        }
      },
      // #endregion

      // #region 流程管理
      {
        path: '/flow',
        name: 'flow',
        component: () => import(/* webpackChunkName: "flow" */ '@/page/flow/flow.vue'),
        meta: {
          title: '流程设置',
          cache: true
        }
      },
      {
        path: '/flowEdit',
        name: 'flowEdit',
        component: () => import(/* webpackChunkName: "flowEdit" */ '@/page/flow/components/flowEdit.vue'),
        meta: {
          title: '流程创建编辑',
          father: '/flow',
          cache: true
        }
      },
      {
        path: '/form',
        name: 'form',
        component: () => import(/* webpackChunkName: "form" */ '@/page/form/form.vue'),
        meta: {
          title: '表单设计',
          cache: true
        }
      },
      {
        path: '/formEdit',
        name: 'formEdit',
        component: () => import(/* webpackChunkName: "formEdit" */ '@/page/form/components/formEdit.vue'),
        meta: {
          title: '表单设计编辑',
          father: '/form',
          cache: true
        }
      },

      // #endregion

      // #region 产品管理
      {
        path: '/product',
        name: 'product',
        component: () => import(/* webpackChunkName: "product" */ '@/page/product/product.vue'),
        meta: {
          title: '产品设置',
          cache: true
        }
      },
      {
        path: '/productClassify',
        name: 'productClassify',
        component: () => import(/* webpackChunkName: "productClassify" */ '@/page/product/productClassify.vue'),
        meta: {
          title: '产品分类设置',
          cache: true
        }
      },
      {
        path: '/productSpec',
        name: 'productSpec',
        component: () => import(/* webpackChunkName: "productSpec" */ '@/page/product/productSpec.vue'),
        meta: {
          title: '产品规格',
          cache: true
        }
      },
      // #endregion
      // #region 客户信息
      {
        path: '/customer',
        name: 'customer',
        component: () => import(/* webpackChunkName: "customer" */ '@/page/customer/customer.vue'),
        meta: {
          title: '客户信息',
          cache: true
        }
      },
       // #endregion
      // #region 供应商信息
      {
        path: '/provider',
        name: 'provider',
        component: () => import(/* webpackChunkName: "provider" */ '@/page/customer/provider.vue'),
        meta: {
          title: '供应商信息',
          cache: true
        }
      },
      // #endregion
      // #region 规格
      {
        path: '/spec',
        name: 'spec',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/spec/spec.vue'),
        meta: {
          title: '规格信息',
          cache: true
        }
      },
      // #endregion
      // #region 采购信息
      {
        path: '/orderBuy',
        name: 'orderBuy',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/order/orderBuy.vue'),
        meta: {
          title: '采购信息',
          cache: true
        }
      },
      // #endregion
      // #region 采购单详情
      {
        path: '/orderBuyEdit',
        name: 'orderBuyEdit',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/order/orderBuyEdit.vue'),
        meta: {
          title: '采购详情',
          cache: true
        }
      },
      // #endregion
      // #region 字典详情
      {
        path: '/dictionary',
        name: 'dictionary',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/dictionaries/dictionary.vue'),
        meta: {
          title: '字典信息',
          cache: true
        }
      },
      // #endregion
      // #region 仓库详情
      {
        path: '/whInfo',
        name: 'whInfo',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/whs/whInfo.vue'),
        meta: {
          title: '仓库信息',
          cache: true
        }
      },
      // #endregion
      // #region 操作记录
      {
        path: '/operLog',
        name: 'operLog',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/operlogs/operLog.vue'),
        meta: {
          title: '操作记录',
          cache: true
        }
      },
      // #endregion
      // #region 登录记录
      {
        path: '/loginLog',
        name: 'loginLog',
        component: () => import(/* webpackChunkName: "spec" */ '@/page/operlogs/loginLog.vue'),
        meta: {
          title: '登录记录',
          cache: true
        }
      }
      // #endregion
    ]
  },

  {
    path: '/login',
    name: 'login',
    component: () => import(/* webpackChunkName: "login" */ '../page/login/index.vue'),
    meta: {
      title: '登录'
    }
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

export default router;
