/*
 * @Author: 赵宇
 * @Description:
 * @Date: 2022-07-25 16:14:34
 * @LastEditTime: 2023-04-19 14:31:24
 * @LastEditors: pancc 527847805@qq.com
 * @FilePath: \pcj\src\config\data.js
 */
import { Flag, User, Avatar, StarFilled } from '@element-plus/icons-vue';
let taskOptions = [
  { value: 1, label: '审批' },
  { value: 2, label: '数量记录' },
  { value: 3, label: '采购/生产入库' },
  { value: 4, label: '生产外发' },
  { value: 5, label: '订单发货' },
  { value: 6, label: '金额记录' },
  { value: 7, label: '收款' },
  { value: 8, label: '付款' },
  { value: 9, label: '状态' },
  { value: 10, label: '业务单编辑' }
];
const productTypeData = [
  { value: 1, label: '成品' },
  { value: 2, label: '半成品' },
  { value: 3, label: '原材料' }
];
const custTypeData = [
  { value: 1, label: '公司共有' },
  { value: 2, label: '个人所有' }
];
const custLevelType = [
  { value: 1, label: 'A' },
  { value: 2, label: 'B' },
  { value: 3, label: 'C' },
  { value: 4, label: 'D' },
  { value: 5, label: 'E' }
];
const specOptions = [
  { label: '单行文本', dataType: '', id: 1 },
  { label: '多行文本', dataType: '', id: 2 },
  { label: '下拉单选', dataType: '', id: 3 },
  { label: '下拉多选', dataType: '', id: 4 },
  { label: '数值', dataType: '', id: 5 },
  { label: '日期选择', dataType: '', id: 6 },
  { label: '公式计算', dataType: '', id: 7 },
  { label: '附件', dataType: '', id: 8 }
];
const selectOptions = [
  { label: '自定义', id: 1 },
  { label: '产品', id: 2 },
  { label: '供应商', id: 3 },
  { label: '客户', id: 4 },
  { label: '供应商等级', id: 5 },
  { label: '币种', id: 6 }
];
const role = [
  {
    id: 1,
    label: '控制台',
    icon: Flag,
    router: '/index'
  },
  {
    id: 2,
    label: '权限管理',
    icon: Flag,
    children: [
      {
        id: 201,
        label: '用户管理',
        icon: User,
        router: '/user',
        isPenultimate: true,
        children: [
          {
            id: 20101,
            label: '查看'
          },
          {
            id: 20102,
            label: '新增'
          },
          {
            id: 20103,
            label: '编辑'
          },
          {
            id: 20104,
            label: '删除'
          }
        ]
      },
      {
        id: 202,
        label: '角色页面管理',
        icon: StarFilled,
        router: '/role',
        isPenultimate: true,
        children: [
          {
            id: 20201,
            label: '查看'
          },
          {
            id: 20202,
            label: '新增'
          },
          {
            id: 20203,
            label: '编辑'
          },
          {
            id: 20204,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 3,
    label: '流程管理',
    icon: StarFilled,
    children: [
      {
        id: 301,
        label: '流程设置',
        icon: User,
        router: '/flow',
        isPenultimate: true,
        children: [
          {
            id: 30101,
            label: '查看'
          },
          {
            id: 30102,
            label: '新增'
          },
          {
            id: 30103,
            label: '编辑'
          },
          {
            id: 30104,
            label: '删除'
          }
        ]
      },
      {
        id: 302,
        label: '表单设计',
        icon: User,
        router: '/form',
        isPenultimate: true,
        children: [
          {
            id: 30201,
            label: '查看'
          },
          {
            id: 30202,
            label: '新增'
          },
          {
            id: 30203,
            label: '编辑'
          },
          {
            id: 30204,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 4,
    label: '产品管理',
    icon: StarFilled,
    children: [
      {
        id: 401,
        label: '产品信息',
        icon: User,
        router: '/product',
        isPenultimate: true,
        children: [
          {
            id: 40101,
            label: '查看'
          },
          {
            id: 40102,
            label: '新增'
          },
          {
            id: 40103,
            label: '编辑'
          },
          {
            id: 40104,
            label: '删除'
          }
        ]
      },
      {
        id: 403,
        label: '分类信息',
        icon: User,
        router: '/productClassify',
        isPenultimate: true,
        children: [
          {
            id: 40301,
            label: '查看'
          },
          {
            id: 40302,
            label: '新增'
          },
          {
            id: 40303,
            label: '编辑'
          },
          {
            id: 40304,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 5,
    label: '客户管理',
    icon: Flag,
    children: [
      {
        id: 501,
        label: '客户信息',
        icon: User,
        router: '/customer',
        isPenultimate: true,
        children: [
          {
            id: 50101,
            label: '查看'
          },
          {
            id: 50102,
            label: '新增'
          },
          {
            id: 50103,
            label: '编辑'
          },
          {
            id: 50104,
            label: '删除'
          }
        ]
      }
      // {
      //   id: 502,
      //   label: '角色页面管理',
      //   icon: StarFilled,
      //   router: '/role',
      //   isPenultimate: true,
      //   children: [
      //     {
      //       id: 50201,
      //       label: '查看'
      //     },
      //     {
      //       id: 50202,
      //       label: '新增'
      //     },
      //     {
      //       id: 50203,
      //       label: '编辑'
      //     },
      //     {
      //       id: 50204,
      //       label: '删除'
      //     }
      //   ]
      // }
    ]
  },
  {
    id: 6,
    label: '供应商管理',
    icon: Flag,
    children: [
      {
        id: 601,
        label: '供应商信息',
        icon: User,
        router: '/provider',
        isPenultimate: true,
        children: [
          {
            id: 60101,
            label: '查看'
          },
          {
            id: 60102,
            label: '新增'
          },
          {
            id: 60103,
            label: '编辑'
          },
          {
            id: 60104,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 7,
    label: '规格管理',
    icon: Flag,
    children: [
      {
        id: 601,
        label: '规格设置',
        icon: User,
        router: '/spec',
        isPenultimate: true,
        children: [
          {
            id: 70101,
            label: '查看'
          },
          {
            id: 70102,
            label: '新增'
          },
          {
            id: 70103,
            label: '编辑'
          },
          {
            id: 70104,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 8,
    label: '单据管理',
    icon: Flag,
    children: [
      {
        id: 801,
        label: '采购单',
        icon: User,
        router: '/orderBuy',
        isPenultimate: true,
        children: [
          {
            id: 80101,
            label: '查看'
          },
          {
            id: 80102,
            label: '新增'
          },
          {
            id: 80103,
            label: '编辑'
          },
          {
            id: 80104,
            label: '删除'
          }
        ]
      },
      {
        id: 802,
        label: '销售单',
        icon: User,
        router: '/order',
        isPenultimate: true,
        children: [
          {
            id: 80201,
            label: '查看'
          },
          {
            id: 80202,
            label: '新增'
          },
          {
            id: 80203,
            label: '编辑'
          },
          {
            id: 80204,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 9,
    label: '业务管理',
    icon: Flag,
    children: [
      {
        id: 901,
        label: '字典',
        icon: User,
        router: '/dictionary',
        isPenultimate: true,
        children: [
          {
            id: 90101,
            label: '查看'
          },
          {
            id: 90102,
            label: '新增'
          },
          {
            id: 90103,
            label: '编辑'
          },
          {
            id: 90104,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 10,
    label: '库存管理',
    icon: Flag,
    children: [
      {
        id: 1001,
        label: '仓库',
        icon: User,
        router: '/whInfo',
        isPenultimate: true,
        children: [
          {
            id: 100101,
            label: '查看'
          },
          {
            id: 100102,
            label: '新增'
          },
          {
            id: 100103,
            label: '编辑'
          },
          {
            id: 100104,
            label: '删除'
          }
        ]
      }
    ]
  },
  {
    id: 11,
    label: '日志详情',
    icon: Flag,
    children: [
      {
        id: 1101,
        label: '操作记录',
        icon: User,
        router: '/operLog',
        isPenultimate: true,
        children: [
          {
            id: 110101,
            label: '查看'
          }
        ]
      },
      {
        id: 1102,
        label: '登录记录',
        icon: User,
        router: '/loginLog',
        isPenultimate: true,
        children: [
          {
            id: 110201,
            label: '查看'
          }
        ]
      }
    ]
  }
];
export { taskOptions, role, specOptions, selectOptions, productTypeData, custTypeData, custLevelType };
