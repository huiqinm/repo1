/*
 * @Author: 赵宇
 * @Description: 自定义指令合集
 * @Date: 2023-02-23 16:02:03
 * @LastEditTime: 2023-03-13 17:42:25
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\src\config\directives.js
 */

export default function directives(app) {
  // 节流指令 默认是500毫秒 可以自己定义 v-debounce:1000="xxx"
  app.directive('debounce', {
    beforeMount: (el, binding) => {
      let input = el.querySelector('input');
      let timer;
      input.addEventListener('keyup', () => {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => {
          binding.value();
          timer = null;
        }, binding.arg || 500);
      });
    }
  });
  // 聚焦指令
  app.directive('focus', {
    mounted: el => {
      setTimeout(() => {
        el.querySelector('input').focus();
      });
    }
  });
  // 节流指令 默认是500毫秒 可以自己定义 v-click:1000="xxx"
  app.directive('click', {
    beforeMount: (el, binding) => {
      let timer;
      el.addEventListener('click', () => {
        if (timer) clearTimeout(timer);
        timer = setTimeout(() => {
          binding.value();
          timer = null;
        }, binding.arg || 500);
      });
    }
  });
}
