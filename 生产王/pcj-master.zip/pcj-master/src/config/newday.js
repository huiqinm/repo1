/*
 * @Author: pancc 527847805@qq.com
 * @Date: 2023-04-21 13:28:49
 * @LastEditors: pancc 527847805@qq.com
 * @LastEditTime: 2023-04-27 16:29:11
 * @FilePath: \pcj\src\config\newday.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
import dayjs from 'dayjs';

let extDay = (val) => {
    let res = dayjs(val).format("YYYY-MM-DD");
    if (res === '1901-01-01') return '无'
    return res;
}

let extDayTime = (val) => {
    let res = dayjs(val).format("YYYY-MM-DD HH:mm:ss");
    if (res === '1901-01-01') return '无'
    return res;
}

export { extDay, extDayTime }