/*
 * @customMade: 赵宇
 * @Date: 2022-03-08 13:44:29
 * @LastEditTime: 2023-04-18 11:35:34
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\src\config\global.js
 */
import { role } from '@/config/data.js';
let timer = null;
let timeoutArr = [];
let flagArr = [];
let global = {
  numTransform(val, num = 2) {
    val = (parseFloat(val) || 0) + '';
    return parseFloat(val.replace(eval(`/([0-9]+.[0-9]{${num}})[0-9]*/`), '$1') || 0);
  },
  // 是否是手机号
  isPhone(value) {
    return /^1[3-9]\d{9}$/.test(value);
  },
  // 数字 千分位格式化
  toThousands(num, decimal = 0) {
    num = decimal ? global.numTransform(num, decimal) : num;
    num = num + '';
    num = num.split('.');
    return num[0].toString().replace(/(\d)(?=(\d{3})+\b)/g, '$1,') + (num[1] ? '.' + num[1] : '');
  },
  // 数据重组
  dataProcess(val, parent, globalLabel = '全公司') {
    let arr = JSON.parse(JSON.stringify(val));
    let obj = { 0: { label: globalLabel, value: 0, children: [] } };
    arr.map(r => (obj[r.id] = r));
    arr.map(r => {
      if (obj[r[parent]]) {
        obj[r[parent]].children ? obj[r[parent]].children.push(r) : (obj[r[parent]].children = [r]);
      }
    });
    return [obj[0]];
  },
  // 生成一个随机数
  hash(num = 20) {
    let s = '';
    const strs = [
      ...['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'],
      ...['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'],
      ...['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    ];
    for (let i = 0; i < num; i++) {
      s += strs[Math.floor(Math.random() * strs.length)];
    }
    return s;
  },
  // 是否有权限
  purview(val) {
    // val 1: 查看页面权限 2：新增权限 3：修改 4：删除
    let { state } = useStore();
    let route = useRoute();
    let { permissionIds } = state.commons;
    // 如果没取到权限，或者权限为空，直接不显示按钮
    if (!permissionIds || !permissionIds.length) return;
    let path = route.path;
    let id = null;
    // 根据 当前路由找到页面id
    role.map(r => {
      if (id) return;
      if (r.children) {
        let row = r.children.find(n => n.router === path);
        id = row ? row.id : undefined;
      } else if (path === r.router) {
        id = r.id;
      }
    });
    // 如果没找到id,也直接返回了得了。
    if (!id) return;
    return permissionIds.includes(id * 100 + val);
  },
  // 判断是不是json
  isJson(str) {
    try {
      JSON.parse(str);
    } catch (_) {
      return false;
    }
    return true;
  },
  // 防抖函数
  debounce(callback, val, wait = 200) {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      callback(val);
      timer = null;
    }, wait);
  },
  /**
   * 节流函数
   * 节流原理：在一定时间内，只能触发一次
   * @param {Function} fn 要执行的回调函数
   * @param {Number} time 延时的时间
   * @param {Boolean} isImmediate 是否立即执行
   * @param {String} timeoutName 定时器ID
   * @return null
   */
  throttle(fn, time = 500, isImmediate = true, timeoutName = 'default') {
    if (!timeoutArr[timeoutName]) timeoutArr[timeoutName] = null;
    if (isImmediate) {
      if (!flagArr[timeoutName]) {
        flagArr[timeoutName] = true;
        // 如果是立即执行，则在time毫秒内开始时执行
        if (typeof fn === 'function') fn();
        timeoutArr[timeoutName] = setTimeout(() => {
          flagArr[timeoutName] = false;
        }, time);
      }
    } else {
      if (!flagArr[timeoutName]) {
        flagArr[timeoutName] = true;
        // 如果是非立即执行，则在time毫秒内的结束处执行
        timeoutArr[timeoutName] = setTimeout(() => {
          flagArr[timeoutName] = false;
          if (typeof fn === 'function') fn();
        }, time);
      }
    }
  }
};
export { global };
