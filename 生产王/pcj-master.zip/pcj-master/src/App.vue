<!--
 * @customMade: 赵宇
 * @Date: 2022-02-17 15:31:09
 * @LastEditTime: 2023-04-20 14:23:39
 * @LastEditors: pancc 527847805@qq.com
 * @FilePath: \pcj\src\App.vue
-->

<template>
  <el-config-provider :locale="zhCn" :size="size">
    <router-view />
  </el-config-provider>
</template>
<script setup>
import zhCn from 'element-plus/lib/locale/lang/zh-cn';
import { provide, watch } from 'vue';
import dayjs from 'dayjs';
import { global } from '@/config/global';
import 'element-plus/theme-chalk/el-notification.css';
import 'element-plus/theme-chalk/el-message.css';
// 特别注释，这里单独引入了 loading 的css，因为自动导入并没有引入这部分样式，所以单独引入。
import 'element-plus/theme-chalk/el-loading.css';
provide('$notify', ElNotification);
provide('$message', ElMessage);
provide('$day', dayjs);
provide('$global', global);

const router = useRouter();
const route = useRoute();

let size = 'default';
watch(
  () => route.path,
  val => {
    if (val === '/' || val === '/login') return;
    if (!localStorage.getItem('token')) {
      ElMessage.info('未登录，请先登录!');
      router.push('login');
    }
  },
  {
    immediate: true
  }
);
</script>
<style lang="scss">
$icon: '//at.alicdn.com/t/c/font_3181422_uikgzbqmpac.css';
@import url($icon);
#app {
  height: 100%;
  overflow: hidden;
  box-sizing: border-box;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
</style>
