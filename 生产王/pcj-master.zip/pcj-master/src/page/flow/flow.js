let flowNodeDefault = val => {
  return {
    ...{
      prop: 'approval',
      taskName: '', // 节点名称
      taskType: 0, // 节点类型 （1.审批，2.数量，3.采购入库，4.外发，5.发货,6.金额，7.收款，8.付款，9.状态，10，业务单编辑）
      ourTaskId: 0, //图形Id
      id: 0, //图形Id
      parentIds: [], //父级节点
      defaultAbortDateType: 0, // 截止日期设置类型：1.订单后，2.节点完成后
      currentOurTaskId: 0, // 截止日期设置为节点的Id
      distanceHour: 0, // 截止日期设置距离小时
      isAutoFinish: false, //是否自动完成
      isMustFinish: false, // 是否必须完成
      relevanceOurTaskId: 0, // 金额关联数量
      amountScale: 100, // 金额取订单金额比例,100%= 1
      changeOfficeTypes: [], // 变更负责人权限
      anybody: 0,
      setAbortDateTypes: [], // 变更截止日期权限
      anybodyDate: 0, // 变更截止日期权限
      templateProgressId: 0,
      auditLevelType: 1, // 审批等级
      orderAudits: [], // 审批成员
    },
    ...val
  };
};

export { flowNodeDefault };
