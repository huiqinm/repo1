<!--
 * @Author: 赵宇
 * @Description: 
 * @Date: 2023-02-01 17:32:13
 * @LastEditTime: 2023-03-06 15:47:12
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\src\page\auth\components\depEdit.vue
-->
<template>
  <div class="dep">
    <el-dialog draggable v-model="dialog.show" width="600px" :before-close="handleClose" class="custom-dialog">
      <template #header> {{ props.editData.id ? '修改' : '新增' }}部门 </template>
      <el-form :model="forms" ref="registerRef" :rules="rules" label-width="100" class="dis-flex flex-dir-column flex-center">
        <el-form-item label="名称" prop="deptMentName">
          <el-input v-model="forms.deptMentName" placeholder="部门名称" autofocus clearable class="width-220"></el-input>
        </el-form-item>
        <el-form-item label="上级部门" prop="deptParentId">
          <el-tree-select
            v-model="forms.deptParentId"
            default-expand-all
            highlight-current
            check-strictly
            :data="props.depOptions"
            placeholder="选择上级部门"
            class="width-220"
          >
          </el-tree-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <z-button type="" @click="handleClose" icon="close">取消</z-button>
          <z-button icon="check" @click="onCheck" :loading="dialog.loading"> 确认 </z-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { post } from '@/api/index';
let $message = inject('$message');
let emit = defineEmits(['update:modelValue', 'onSave']);
let props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  depOptions: {
    type: Array,
    default: () => {
      return [];
    }
  },
  editData: {
    type: Array,
    default: () => {
      return [];
    }
  }
});
let registerRef = ref();
let dialog = reactive({
  show: false,
  options: [],
  loading: false
});
let formsInit = () => {
  return reactive({
    deptMentName: '',
    deptParentId: 0,
    id: 0
  });
};
let forms = formsInit();
let rules = {
  deptMentName: [{ required: true, trigger: 'blur', message: '部门名称不能为空!' }],
  deptParentId: [{ required: true, trigger: 'blur', message: '必须选择上级部门!' }]
};
watch(
  () => props.modelValue,
  val => {
    dialog.show = val;
    if (!val) return;
    const formData = formsInit();
    Object.keys(formData).map(r => {
      forms[r] = props.editData[r] != undefined ? props.editData[r] : formData[r];
    });
  },
  {
    immediate: true
  }
);
const handleClose = () => {
  emit('update:modelValue', false);
};
const onCheck = () => {
  if (!registerRef.value) return;
  registerRef.value.validate(async val => {
    if (!val) return;
    try {
      dialog.loading = true;
      await post('DeptMent/AddOrUpdate', forms);
      $message.success('编辑成功');
      dialog.loading = false;
      emit('onSave');
    } catch (error) {
      console.log('DeptMent/AddOrUpdate错误', error);
      dialog.loading = false;
    }
  });
};
</script>

<style lang="scss" scoped>
.dep {
  :deep(.custom-dialog) {
    .el-dialog__body {
      height: 200px;
    }
  }
}
</style>
