<template>
  <!-- 菜单-->
  <div class="index">
    我是首页
  </div>
</template>

<script setup>
</script>

<style lang="scss" scoped>
</style>
