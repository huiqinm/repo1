<template>
    <div class="orderBuy">
        <ul class="header-buttons">
            <li>
                <z-button title="刷新" icon="refresh" color="#40485b" @click="pageQuery"> </z-button>
                <z-button icon="add" @click="onAdd" v-if="purview(2)">新增</z-button>
            </li>
            <li class="dis-flex">
                <el-input v-model="params.keyword" v-debounce="pageQuery" @clear="pageQuery" placeholder="支持名称模糊搜索"
                    clearable class="mr-10"></el-input>
                <columnSetting v-model="table.columns" name="Product/GetPage" />
                <!-- <z-button icon="query" type="" title="展开通用搜索" @click="status.queryShow = !status.queryShow"></z-button> -->
            </li>
        </ul>
        <o-table :tableData="table.data" :tableTotal="table.totalCount" @onTaskSelBack="onTaskSelBack"
            @onUrgentEditBack="onUrgentEditBack" @onSerialClickBack="onSerialClickBack" @onChangePage="onChangePage" />
        <o-drawer v-model="drawer.show" :editData="drawer.editData" @onTaskEditBack="onTaskEditBack"
            @onAuditPassBack="onAuditPassBack" @onAuditBack="onAuditBack" @onMoreAuditBack="onMoreAuditBack"
            @onAmountSubmitBack="onAmountSubmitBack" @onReportSwitchBack="getOrderWorkReport" @onLoad="onLoad">
        </o-drawer>

    </div>
</template>

<script setup>
import { post } from '@/api/index';
import { get } from '@/api/index';
import { inject, reactive } from 'vue';
let router = useRouter();
let day = inject('$day');
let $message = inject('$message');
let { purview } = inject('$global');
let params = reactive({
    pageIndex: 1,
    pageSize: 20,
    keyword: ''
});

let table = reactive({
    data: [],
    totalCount: 0,
    selection: []
});

let drawer = reactive({
    id: 0,
    show: false,
    loading: false,
    reportSwitch: false,
});

// 查询分页
let pageQuery = async () => {
    let { result } = await post('OrderBuy/GetPage', params);
    table.data = result.items.map(r => {
        return {
            ...r,
            ...{
                initiateDate: day(r.initiateDate).format('YYYY-MM-DD'),
                abortDate: day(r.abortDate).format('YYYY-MM-DD')
            }
        };
    });
    if (result.columnJson) table.columns = JSON.parse(result.columnJson);
    table.totalCount = result.totalCount;
};

// 添加采购单
let onAdd = () => {
    router.push({ path: 'orderBuyEdit', query: { id: 0 } })
};

// 点击查询节点详情
let onTaskSelBack = async (val) => {
    if (val) drawer.id = val.id;
    let { result } = await get('OrderBuyTask/GetModel', { id: drawer.id });
    drawer.editData = { ...result, sourceType: 1002 };
    await getOrderWorkReport();
    drawer.show = true;
};

// 切换加急状态
let onUrgentEditBack = async (val) => {
    await get('OrderBuy/UpdateUrgent', { id: val.id })
    $message.success('修改成功');
    pageQuery();
};

// 点击编号事件
let onSerialClickBack = (val) => {
    router.push({ path: 'orderBuyEdit', query: { id: val.id } })
}

// 分页改变事件
let onChangePage = (val) => {
    params = { ...params, ...val };
    pageQuery();
}

// 查询工作报告
const getOrderWorkReport = async () => {
    let { result } = await post('OrderWorkReport/GetPage', { sourceId: drawer.editData.orderBuyId, sourceType: 1002, SourceTaskId: drawer.reportSwitch ? 0 : drawer.editData.id, pageIndex: 1, pageSize: 999 });
    drawer.editData = { ...drawer.editData, ...{ orderWorkReports: result.items } }
}

// 切换工作报告状态
const onReportSwitchBack = async (val) => {
    drawer.reportSwitch = val;
    await getOrderWorkReport();
}

// 保存节点
const onTaskEditBack = async (val) => {
    await post('OrderBuyTask/Update', val);
    $message.success("修改成功");
    await onTaskEdit();
};

// 审核通过
const onAuditPassBack = async (val) => {
    // emit('onAuditPass', { id: forms.id, content: "通过" });
    await post('OrderBuyTask/Audit', val);
    $message.success("审核通过");
    await onTaskEdit();
};

// 撤销审批
const onAuditBack = async (val) => {
    await post('OrderBuyTask/AuditBack', val);
    $message.success("驳回成功");
    await onTaskEdit();
}

// 审核(通过/驳回)
const onMoreAuditBack = async (val) => {
    if (!val) return;
    if (val.submitType === 1) {
        await post('OrderBuyTask/Audit', val);
        $message.success("提交成功");
    } else if (val.submitType === 2) {
        await post('OrderBuyTask/AudtReject', val);
        $message.success("驳回成功");
    }
    await onTaskEdit();
}

// 添加或编辑金额
const onAmountSubmitBack = async (val) => {
    if (val) {
        if (val.submitType === 1) {// 修改金额
            await post('OrderBuyTask/UpdateAmount', val);
        } else {
            val["orderBuyTaskId"] = val.id;
            await post('OrderBuyAmountRecord/Create', val);
        }
    }
}

// 加载详情页
const onLoad = () => {
    onTaskSelBack();
    getOrderWorkReport();
}

// 初始化
onActivated(() => {
    pageQuery();
});
</script>


<style lang="scss" scoped>
.orderBuy {
    height: 100%;
    background-color: #fff;
    padding: 10px;

    .header-buttons {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }
}
</style>

