<template>
  <div class="dictionaryValue">
    <el-dialog draggable v-model="dialog.show" width="600px" :before-close="handleClose" class="custom-dialog">
      <template #header> 新增其他费用 </template>
      <el-form :model="forms" ref="registerRef" :rules="rules" label-width="100" class="dis-flex flex-dir-column flex-center">
        <el-form-item label="费用名称" prop="costName">
          <el-input v-model="forms.costName" placeholder="费用名称" autofocus clearable class="width-220"></el-input>
        </el-form-item>
        <el-form-item label="金额" prop="costAmount">
          <el-input-number v-model="forms.costAmount" placeholder="金额" autofocus clearable class="width-220"></el-input-number>
        </el-form-item>
        <el-form-item label="备注" prop="note">
          <el-input v-model="forms.note" placeholder="备注" autofocus clearable class="width-220"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <z-button type="" @click="handleClose" icon="close">取消</z-button>
          <z-button icon="check" @click="onCheck" :loading="dialog.loading"> 确认 </z-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>
<script setup>
import { post } from '@/api/index';
import { reactive } from 'vue';
let $message = inject('$message');
let emit = defineEmits(['update:modelValue', 'onSave']);
let props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  }
});
let dialog = reactive({
  show: false,
  options: [],
  loading: false
});
watch(
  () => props.modelValue,
  async val => {
    dialog.show = val;
    if (!val) return;
    let formData = formsInit();
    // Object.keys(formData).map(r => {
    //     forms[r] = props.editData[r] != undefined ? props.editData[r] : formData[r];
    // });
  },
  {
    immediate: true
  }
);
let registerRef = ref();

const formsInit = () => {
  return reactive({
    costName: '',
    costAmount: 0,
    note: ''
  });
};

let forms = formsInit();

let rules = {
  name: [{ required: true, trigger: 'blur', message: '名称不能为空!' }]
};

const handleClose = () => {
  emit('update:modelValue', false);
};
const onCheck = () => {
  if (!registerRef.value) return;
  registerRef.value.validate(async val => {
    if (!val) return;
    try {
      dialog.loading = true;
      dialog.loading = false;
      emit('onSave', forms);
      forms = formsInit();
    } catch (error) {
      console.log('Category/CreateOrUpdate错误', error);
      dialog.loading = false;
    }
  });
};
</script>

<style lang="scss" scoped>
.classify {
  :deep(.custom-dialog) {
    .el-dialog__body {
      height: 200px;
    }
  }
}
</style>
