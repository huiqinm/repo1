<!--
 * @Author: 赵宇
 * @Description: 
 * @Date: 2023-03-03 11:14:25
 * @LastEditTime: 2023-03-08 16:57:59
 * @LastEditors: zhao 13370229059@163.com
 * @FilePath: \pcj\src\page\product\components\productEdit.vue
-->
<template>
  <el-dialog draggable v-model="dialog.show" width="1140px" top="50px" :before-close="handleClose" class="custom-dialog">
    <template #header> {{ props.editData.id ? '修改' : '新增' }}产品 </template>
    <el-form :model="forms" inline ref="registerRef" :rules="rules" label-width="100">
      <el-form-item label="产品编号" prop="productSerialNo">
        <el-input v-model="forms.productSerialNo" placeholder="产品编号" clearable class="width-220"></el-input>
      </el-form-item>
      <el-form-item label="产品名称" prop="productName">
        <el-input v-model="forms.productName" placeholder="产品名称" clearable class="width-220"></el-input>
      </el-form-item>
      <el-form-item label="产品类型" prop="productType">
        <el-radio-group v-model="forms.productType">
          <el-radio-button :label="item.value" v-for="item in productTypeData" :key="item">
            {{ item.label }}
          </el-radio-button>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="产品分类" prop="categoryId">
        <el-tree-select
          v-model="forms.categoryId"
          default-expand-all
          highlight-current
          check-strictly
          :data="dialog.classifyOptions"
          placeholder="选择产品分类"
          @node-click="onNodeClick"
          class="width-220"
        >
        </el-tree-select>
      </el-form-item>
      <el-form-item label="单价" prop="price">
        <z-input v-model="forms.price" placeholder="单价" clearable class="width-220"></z-input>
      </el-form-item>
      <el-form-item label="单位" prop="unit">
        <el-input v-model="forms.unit" placeholder="单位" clearable class="width-220"></el-input>
      </el-form-item>
      <el-form-item label="预警库存" prop="warnNumber">
        <z-input v-model="forms.warnNumber" placeholder="预警库存" clearable class="width-220"></z-input>
      </el-form-item>
      <el-form-item label="状态" prop="statusId">
        <el-switch v-model="forms.statusId" :active-value="1" :inactive-value="0" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949">
        </el-switch>
      </el-form-item>
      <div class="w-100 dis-flex flex-center">
        <el-form-item label="备注" prop="note" class="flex-1 flex-y-center">
          <el-input v-model="forms.note" type="textarea" placeholder="备注" clearable class="w-100"></el-input>
        </el-form-item>
      </div>
    </el-form>
    <div class="unit">
        <el-alert title="多单位信息" type="success" center :closable="false" class="mb-10" />
        <z-button icon="add" type="success" size="small" title="添加多单位" circle class="unit-button" @click="onUnit"></z-button>
      </div>
      <el-table :data="forms.productMultiUnits" border stripe class="mb-20">
        <el-table-column prop="viceUnit" label="单位名称">
          <template #default="scope">
            <el-input v-model="scope.row.viceUnit" placeholder="请输入单位名称" clearable></el-input>
          </template>
        </el-table-column>
        <el-table-column prop="unitRate" label="转换率">
          <template #default="scope">
            <el-input-number :min="1" v-model="scope.row.unitRate" placeholder="请输入与主单位转换率" clearable></el-input-number>
          </template>
        </el-table-column> 
        <el-table-column label="操作" align="center" width="120">
          <template #default="scope">
            <z-button icon="delete" type="danger" size="small" circle title="删除" @click="onUnitDel(scope.$index)"></z-button>
          </template>
        </el-table-column>
      </el-table>
    <el-collapse-transition>
      <div v-show="!!dialog.spec.length">
        <el-alert title="产品规格" type="success" center :closable="false" class="mb-10" />
        <spec :data="dialog.spec" ref="specRef" />
      </div>
    </el-collapse-transition>
    <template #footer>
      <span class="dialog-footer">
        <z-button type="" @click="handleClose" icon="close">取消</z-button>
        <z-button icon="check" @click="onCheck" :loading="dialog.loading"> 确认 </z-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { get, post } from '@/api/index';
import { productTypeData } from '@/config/data';
let $message = inject('$message');
let emit = defineEmits(['update:modelValue', 'onSave']);
let { dataProcess } = inject('$global');
let store = useStore();
let props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  editData: {
    type: Object,
    default: () => {
      return {};
    }
  }
});
let registerRef = ref();
let specRef = ref();
let dialog = reactive({
  show: false,
  classifyOptions: [],
  spec: [],
  loading: false,
  isFirst: true
});
let formsInit = () => {
  return reactive({
    id: 0,
    categoryId: undefined,
    imagePaths: '',
    productSerialNo: '',
    productName: '',
    productType: 1,
    extraSpec: '',
    unit: '',
    price: 0,
    warnNumber: 0,
    statusId: 1,
    attributeValStr: '',
    note: '',
    idSorted: 0,
    customSpecValueDic: {},
    productMultiUnits: []
  });
};
let forms = formsInit();
let rules = {
  productName: [{ required: true, trigger: 'change', message: '名称不能为空!' }],
  productSerialNo: [{ required: true, trigger: 'change', message: '编号不能为空!' }],
  categoryId: [{ required: true, trigger: 'change', message: '产品分类不能为空!' }],
  productType: [{ required: true, trigger: 'change', message: '产品类型不能为空!' }]
};
let categorys = computed(() => store.state.categorys);
watch(
  () => props.modelValue,
  async val => {
    dialog.show = val;
    if (!val) return;
    // 看产品分类有没有数据
    if (!categorys.value.length) await store.dispatch('getCategory');
    dialog.classifyOptions = dataProcess(categorys.value, 'categoryParentId')[0].children;
    if (props.editData.id) {
      getDetail();
      return;
    }
    dialog.spec = [];
    const formData = formsInit();
    Object.keys(formData).map(r => {
      forms[r] = props.editData[r] != undefined ? props.editData[r] : formData[r];
    });
  },
  {
    immediate: true
  }
);
// 关闭
const handleClose = () => {
  registerRef.value.resetFields();
  emit('update:modelValue', false);
};
// 确认
const onCheck = async () => {
  if (!registerRef.value) return;
  registerRef.value.validate(async val => {
    if (!val) return;
    let specCheck = dialog.spec.length ? await specRef.value.check() : true;
    if (!specCheck) return;
    try {
      dialog.loading = true;
      await post('Product/CreateOrUpdate', { ...forms, customSpecValueDic: specCheck });
      $message.success(`${props.editData.id ? '修改' : '新增'}成功`);
      dialog.loading = false;
      emit('onSave');
      registerRef.value.resetFields();
    } catch (error) {
      console.log('DeptMent/AddOrUpdate错误', error);
      dialog.loading = false;
    }
  });
};
// 点击产品分类
const onNodeClick = val => {
  getSpecList(val.id);
};
// 获取规格
const getSpecList = async id => {
  let { result } = await post('CustomCategorySpec/GetList', { pageSize: 999, pageIndex: 1, categoryId: id, isNotContain: false });
  dialog.spec = result.items;
};
// 详情接口
const getDetail = async () => {
  let { result } = await get('Product/GetModel', { id: props.editData.id });
  const formData = formsInit();
  Object.keys(formData).map(r => {
    forms[r] = result[r] != undefined ? result[r] : formData[r];
  });
  dialog.spec = result.customObjectValues;
};

// 添加联系人
const onUnit = () => {
  forms.productMultiUnits.push({
    viceUnit: '',
    unitRate: 1
  });
};

// 删除联系人
const onUnitDel = index => {
  forms.productMultiUnits.splice(index, 1);
};
</script>

<style lang="scss" scoped>
.unit {
  position: relative;
  :deep(.unit-button) {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
  }
}
</style>
