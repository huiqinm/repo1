<template>
  <div class="tags">
    <div class="tags-box">
      <el-tag
        v-for="(item, index) in props.modelValue"
        :key="index"
        :closable="props.modelValue.length > 1"
        class="tags-element"
        :effect="isActive(item.fullPath) ? 'dark' : ''"
        @close="closeTags(index)"
        @click="go(item)"
      >
        {{ item.title }}
      </el-tag>
    </div>
    <div class="tags-close-box" v-show="props.modelValue.length > 1">
      <z-button type="danger" @click="closeOther" icon="close" size="small">关闭其他</z-button>
    </div>
  </div>
</template>

<script setup>
let emit = defineEmits(['closeOther', 'closeTags']);
let route = useRoute();
let router = useRouter();
let props = defineProps({
  modelValue: {
    type: Array,
    default: () => {
      return [];
    }
  }
});
const isActive = fullPath => {
  return fullPath === route.fullPath;
};
// 关闭单个标签
const closeTags = index => {
  emit('closeTags', index);
};
// 关闭其他标签
const closeOther = () => {
  emit('closeOther');
};
// 跳转页面
const go = val => {
  // 如果他点击的是当前路由，不用处理
  if (val.fullPath === route.fullPath) return;
  router.push(val.fullPath);
};
</script>

<style lang="scss">
.tags {
  display: flex;
  justify-content: space-between;
  align-items: center;
  &-box {
    display: flex;
    overflow-x: auto;
  }
  &-element {
    margin-right: 10px;
    cursor: pointer;
    &:hover {
      color: #f56c6c;
      transition: all 0.3s;
    }
  }
}

.tags-close-box {
  z-index: 10;
}
</style>
