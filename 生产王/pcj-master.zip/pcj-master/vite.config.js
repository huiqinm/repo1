/*
 * @customMade: 赵宇
 * @Date: 2022-02-17 15:31:09
 * @LastEditTime: 2023-05-06 18:07:19
 * @LastEditors: pancc 527847805@qq.com
 * @FilePath: \pcj\vite.config.js
 */
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { viteMockServe } from 'vite-plugin-mock';
import Icons from 'unplugin-icons/vite';
import IconsResolver from 'unplugin-icons/resolver';
import path from 'path';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';
import VueSetupExtend from 'vite-plugin-vue-setup-extend';
const pathSrc = path.resolve(__dirname, 'src');

export default defineConfig({
  base: './',
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
      comps: path.resolve(__dirname, 'src/components'),
      page: path.resolve(__dirname, 'src/page')
    }
  },
  server: {
    port: 8000,
    hmr: true,
    proxy: {
      // 本地开发环境通过代理实现跨域，生产环境使用 nginx 转发
      '^/api': {
        // target: 'http://localhost:62114/api/services/app',
        target: 'http://192.168.50.128:8088/api/services/app',
        // target: 'http://101.43.17.114/api/services/app',
        changeOrigin: true,
        rewrite: path => path.replace(/^\/api/, '')
      }
    }
  },
  plugins: [
    vue(),
    VueSetupExtend(),
    viteMockServe({
      supportTs: false
    }),
    AutoImport({
      // 自动导入 Vue 相关函数，如：ref, reactive, toRef 等
      imports: ['vue', 'vue-router', 'vuex'],
      // 自动导入 Element Plus 相关函数，如：ElMessage, ElMessageBox... (带样式)
      resolvers: [
        ElementPlusResolver(),
        IconsResolver({
          prefix: 'Icon'
        })
      ]
    }),

    Components({
      resolvers: [
        ElementPlusResolver(),
        IconsResolver({
          enabledCollections: ['ep']
        })
      ],
      // 可以让我们使用自己定义组件的时候免去 import 的麻烦
      dirs: ['src/components/'],
      // 配置需要将哪些后缀类型的文件进行自动按需引入
      extensions: ['vue', 'md']
    }),
    Icons({
      autoInstall: true
    })
  ],
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@import "@/styles/color.scss";`
      }
    }
  },

  build: {
    // 生产环境移除 console debugger
    compress: {
      drop_console: true,
      drop_debugger: true
    },
    reportCompressedSize: false
  }
});
